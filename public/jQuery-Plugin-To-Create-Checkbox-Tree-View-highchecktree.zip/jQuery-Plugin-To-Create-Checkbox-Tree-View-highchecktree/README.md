# highchecktree
A jquery plugin that can generate a check tree with special source data, and can deal with big data with high performance.

This plugin was extended by jquery.checktree.js writed by JJ Geewax, thanks for his great work. If your don't need to handle large amouts of data, jquery.checktree.js could be a better choice. 

jquery.highchecktree.js use lazy load to improvement the performance, the children nodes are loaded when you check or expend the parent node.

If you have any concerns, please don't be hesitate to contact me with the email: yanxk888@163.com.
